package com.autome.mixin;

import com.autome.AutoMeClient;
import net.minecraft.class_408;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_408.class)
public class ChatScreenMixin {

    @ModifyVariable(
            method = "sendMessage",
            at = @At("HEAD"),
            argsOnly = true
    )
    private String autome_transformMessage(String message) {
        return AutoMeClient.transformMessage(message);
    }
}
